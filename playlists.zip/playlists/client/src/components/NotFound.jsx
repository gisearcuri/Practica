const NotFound = () => { 
    return(
        <div style={{height: '100%'}}>
            <h2>Nada por aqui</h2>
            <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExY3AyYTRhNmxubGQ0cjNqdHhueWduNjZmdWgzaDV1N2ttY2Z6bDFrbCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/5x89XRx3sBZFC/giphy.gif" alt="Not Found"></img>
        </div>
    )
}

export default NotFound;