import axios from 'axios'
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const BebidasApi = ({ setListaBebidas, login, setLogin , cerrarSesion}) => {
    const navigate = useNavigate();

    const getDataBebidas = () => {
        const URL = 'http://localhost:8000/api/bebidas';

        axios.get(URL, {
            headers: { token_usuario: localStorage.getItem("token") }
        })
        .then(response => {
            setListaBebidas(response.data);
            setLogin(true);
        })
        .catch(e => {
                console.log("ERROR COMPLETO:", e.response.data);
                if (e.response.status === 401){
                cerrarSesion()
                }    setErrors(e.response.data.errors);
            }
        );
    };

    useEffect(() => {
        getDataBebidas();
    }, []);

    return null;
};

export default BebidasApi;