import {Router} from 'express'
import playlistControlador from '../controlador/playlists.controlador.js'


const playlistRuta = Router();

playlistRuta.get('/', playlistControlador.getAll)
playlistRuta.post('/', playlistControlador.createOne)

export default playlistRuta