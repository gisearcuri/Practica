import { cancionesSchema } from "../modelos/canciones.modelos.js";
import Playlist from "../modelos/playlists.modelos.js";
import { Canciones } from "../modelos/canciones.modelos.js";

const playlistControlador = {
    getAll: async (req,res)=> {
        try{
            const playlistEntera = await Playlist.find();
            return res.status(201).json(playlistEntera)
        }catch(e){
            return res.status(400).json(e)
        }
    },
    createOne : async (req, res)=>{
        const {nombre,canciones} = req.body;
        try{
        const foundCanciones = await Canciones.find({titulo : {$in : canciones}})
        if(foundCanciones.length !== canciones.length){
            return res.status(400).json({message: "Una de las canciones "})
        }
        const nuevoArray = {
            nombre: nombre,
            canciones : foundCanciones
        }
        
        const savedPlaylist = await Playlist.create(nuevoArray)
        res.status(201).json(savedPlaylist)
        }catch(e){
            return res.status(400).json(e)
        }
    }
}

export default playlistControlador;