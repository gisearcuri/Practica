import jwt from 'jsonwebtoken';

const SECRET = process.env.SECRET;

const validateToken = (req, res, next) => {
    const token = req.headers.token_usuario;

    if (!token) {
        return res.status(401).json({ message: "No se envió token" });
    }

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: "Token inválido o expirado" });
        }

        req.infoUser = decoded;
        next();
    });
};

export default validateToken;