import { useState } from 'react'
import PlaylistApi from "./components/PlaylistApi";
import 'bootstrap/dist/css/bootstrap.min.css'   
import 'bootstrap/dist/js/bootstrap.bundle.min.js' 


const Playlists = () => {

const [listaPlaylists, setListaPlaylists] = useState([])

    return(
        <>
        <h1>Todas las Playlists</h1>
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Busca playlists" aria-label="Busca playlists" aria-describedby="basic-addon1"></input>
        </div>    
            <PlaylistApi setListaPlaylists={setListaPlaylists}/>
            <ul class="list-group">{listaPlaylists.map(playlist =>
                <li class="list-group-item">{playlist.nombre}</li>
                )}
            </ul>
        </>
    )
}