import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import NotFound from "./NotFound";

const Cancion = ({listaCanciones, setListaCanciones}) => {
    const [persona, setPersona] = useState({})
    const [error, setError] = useState('')
    const {id} = useParams();
    const URL = `http://localhost:8000/api/canciones/${id}`
    const navigate = useNavigate();

    const getData = ()=>{
        axios(URL).then(response =>
            setPersona(response.data)
        ).catch(
            e=> setError(e)
        )
    }

    useEffect(()=>{
        getData()
    },[])



    const borrar= ()=>{
        axios.delete(URL).then(
            response => {
                setListaCanciones(listaCanciones.filter(cancion => cancion._id != id))
                navigate('/canciones')
            }
        ).catch(
            e => console.log(e)
        )
    }
    return(
        <div>
            <h2>Detalle de cancion:</h2>
            <p> Titulo: {persona.titulo}</p>
            <p> Artista: {persona.artista}</p>
            <p> Lanzamiento : {persona.anioLanzamiento}</p>
            <p> Genero: {persona.genero}</p>
            <button type="submit" className="btn btn-primary" onClick={borrar}>Eliminar</button>
        </div>
    )

}

export default Cancion;